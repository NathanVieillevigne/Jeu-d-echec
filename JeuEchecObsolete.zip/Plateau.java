import java.util.*;

public class Plateau {
	//cases contient donc chaque case du plateau sous forme de tableau de cases.
	public Case[][] cases;
	//Le constructeur de plateau.
	public Plateau(){
		//On initialise cases avec un tableau de 8 rangées de 8 cases.
		this.cases = new Case[8][8];
		//On parcourt le tableau par les rangées puis par les cases.
		for(int i = 0;i<8;i++){
			char a = 'A';
			for(int y = 0;y<8;y++){
				//si i = 0 alors on crée les pièces 'spéciales' noirs.
				if(i == 0){
					cases[i][0] = new Case(new Tour('A',1),'A',1);
					cases[i][1] = new Case(new Cavalier('B',1),'B',1);
					cases[i][2] = new Case(new Fou('C',1),'C',1);
					cases[i][3] = new Case(new Dame('D',1),'D',1);
					cases[i][4] = new Case(new Roi('E',1),'E',1);
					cases[i][5] = new Case(new Fou('F',1),'F',1);
					cases[i][6] = new Case(new Cavalier('G',1),'G',1);
					cases[i][7] = new Case(new Tour('H',1),'H',1);
					y = 8;
				}
				//si i = 1/6 alors on crée une rangée de pion noirs/blancs.
				else if(i == 1 || i == 6){
					this.cases[i][y] = new Case(new Pion(a,i+1),a,i+1);
					a++;
				}
				//si i = 7 alors on crée les pièces 'spéciales' blanches.
				else if(i == 7){
					cases[i][0] = new Case(new Tour('A',8),'A',8);
					cases[i][1] = new Case(new Cavalier('B',8),'B',8);
					cases[i][2] = new Case(new Fou('C',8),'C',8);
					cases[i][3] = new Case(new Dame('D',8),'D',8);
					cases[i][4] = new Case(new Roi('E',8),'E',8);
					cases[i][5] = new Case(new Fou('F',8),'F',8);
					cases[i][6] = new Case(new Cavalier('G',8),'G',8);
					cases[i][7] = new Case(new Tour('H',8),'H',8);
					y = 8;
				}
				//Pour toutes les autres situations, nous créeons des cases vides.
				else{	
					this.cases[i][y] = new Case(a,i+1);
					a++;
				}
			}
		}
	}
	//Comme nous utilisons des charactères et qu'il est impossible de parcourir des tableaux à l'aide de charactère, cette fonction permet de translater le caractère en chiffre.
	public int chartoInt(char c){
		int a;
		if(c == 'A'){
			a = 0;
		}
		else if(c == 'B'){
			a = 1;
		}	
		else if(c == 'C'){
			a = 2;
		} 
		else if (c == 'D'){
			a = 3;
		}
		else if (c == 'E'){
			a = 4;
		} 
		else if(c == 'F'){
			a = 5;
		}
		else if(c == 'G'){
			a = 6;
		}
		else if(c == 'H'){
			a = 7;
		}
		else{
			a = 0;
		}
		return a;
	}
	//Cette méthode permet de retourner un tableau contenant la rangée et la colonne des deux rois.
	public Object[] getRoi(){
		int rb = 0;
		char cb = 'A';
		int rn = 0;
		char cn ='A';
		Object[] tab;
		for(int i = 0; i<8;i++){
			for(int y = 0; y<8;y++){
				if(this.cases[i][y].contenu != null){
					if(this.cases[i][y].contenu.nom == "Roi"){
						if(this.cases[i][y].contenu.couleur == "Noir"){
							rn = this.cases[i][y].getRangee();
							cn = this.cases[i][y].getColonne();
						}
						else{
							rb = this.cases[i][y].getRangee();
							cb = this.cases[i][y].getColonne();
						}
					}
				}
			}
		}
		tab = new Object[]{rb,cb,rn,cn};
		return tab;
	}
	//Cette méthode permet de vérifier qu'il y a un echec. C'est à dire que le roi peut être manger par une pièce de la couleur adverse.
	public String echec(){
		//Ces variables permettent de retenir l'emplacement des rois.
		Object[] tab = this.getRoi();
		int rb = (int) tab[0];
		char cb = (char) tab[1];
		int rn = (int) tab[2];
		char cn = (char) tab[3];
		//Après avoir obtenu les coordonnées des deux rois, le tableau va être parcouru de nouveau et chacune des pièces du plateau vont être testés afin de savoir si elles ont la posibilité de se déplacer sur la case du roi de la couleur adverse. Si oui, Un échec a lieu. Si non, Rien ne se passe.
		for(int i = 0; i<8;i++){
			for(int y = 0; y<8;y++){
				if(this.cases[i][y].contenu != null){
					//Si la pièce est noir, .deplacement va être testé pour les coordonnées du roi blanc. Si elle peut y aller alors il y a un echec blanc. 
					if(this.cases[i][y].contenu.couleur == "Noir"){
						if(this.cases[i][y].contenu.deplacement(cb,rb) == true){
							return "Echec Blanc";
						}
					}
					
					//L'inverse si la pièce est blanche.
					else if(this.cases[i][y].contenu.couleur == "Blanc"){
						if(this.cases[i][y].contenu.deplacement(cn,rn) == true){
							return "Echec Noir";
						}
					}
				}
			}
		}
		return "Pas Echec";
	}
	
	public Boolean etmath(String echec){
		boolean test = false;
		Object[] tab = this.getRoi();
		int rb = (int) tab[0];
		char cb = (char) tab[1];
		int rn = (int) tab[2];
		char cn = (char) tab[3];
		Case copie;
		if(echec == "Pas Echec"){
			return null;
		}
		else{
			for(int i = 0; i<8;i++){
				for(char y = 'A'; y<'I';y++){
					copie = new Case(this.cases[i][chartoInt(y)]);
					//Si il y a un echec blanc, alors il y a une vérification pour savoir si le roi peut se déplacer.
					//Si il peut, alors il y a un nouveau test echec pour vérifier si il est aussi en echec sur cette case. etc.
					//Si il ne peut pas ou qu'aucune des cases l'entourant n'est sure. Alors il y a un echec et math!
					if(echec == "Echec Blanc"){
						if(this.deplacementPiece(cb,rb,y,i+1) == true){
							if(this.echec() == "Pas Echec"){
								test = this.deplacementPiece(y,i+1,cb,rb);
								this.cases[i][chartoInt(y)] = new Case(copie);
								System.out.println("Je suis Shinwa");
								return null;
							}
							test = this.deplacementPiece(y,i+1,cb,rb);
							this.cases[i][chartoInt(y)] = new Case(copie);
						}
						//Si on atteint la fin du tableau sans possibilité de déplacement alors il y a echec et maths.
						else if(i == 7 && y == 'H'){
							return true;
						}
					}
					
					//Pareillement pour echec noir.
					if(echec == "Echec Noir"){
						if(this.deplacementPiece(cn,rn,y,i+1) == true){
							if(this.echec() == "Pas Echec"){
								test = this.deplacementPiece(y,i+1,cn,rn);
								this.cases[i][chartoInt(y)] = new Case(copie);
								System.out.println("Je suis Shinwa");
								return null;
							}
							test = this.deplacementPiece(y,i+1,cn,rn);
							this.cases[i][chartoInt(y)] = new Case(copie);
						}
						//Si on atteint la fin du tableau sans possibilité de déplacement alors il y a echec et maths.
						else if(i == 7 && y == 'H'){
							return false;
						}
					}
				}
			}
		}
		return null;
	}
	
	public boolean peutTraverser(char c1,int r1,char c2,int r2){
		String TypeMouvement = "Verticale";
		if(c1 == c2){
			TypeMouvement = "Verticale";
		}
		if(r1 == r2){
			TypeMouvement = "Horizontale";
		}
		if((r1 < r2 && chartoInt(c1) > chartoInt(c2)) || (r1 > r2 && chartoInt(c1) < chartoInt(c2))){
			TypeMouvement = "DiagonaleDroiteGauche";
		}
		if((r1 > r2 && chartoInt(c1) > chartoInt(c2)) || (r1 < r2 && chartoInt(c1) < chartoInt(c2))){
			TypeMouvement = "DiagonaleGaucheDroite";
		}
		if(TypeMouvement == "Verticale"){
			if(r1 > r2){
				for(int i = this.cases[r2-1][chartoInt(c2)].getRangee()+1; i<this.cases[r1-1][chartoInt(c1)].getRangee()-1;i++){
					if(this.cases[i][chartoInt(c2)].getContenu() != null){
						System.out.println(this.cases[i][chartoInt(c2)].getContenu());
						return false;
					}
				}
			}
			if(r1 < r2){
				for(int i = this.cases[r2-1][chartoInt(c2)].getRangee()-1; i>this.cases[r1-1][chartoInt(c1)].getRangee();i--){
					if(this.cases[i][chartoInt(c2)].getContenu() != null){
						return false;
					}
				}
			}
		}
		if(TypeMouvement == "Horizontale"){
			if(c1 > c2){
				for(int i = this.cases[r2-1][chartoInt(c2)].getColonne()-1; i<chartoInt(this.cases[r1-1][chartoInt(c1)].getColonne());i--){
					if(this.cases[r2-1][i].getContenu() != null){
						return false;
					}
				}
			}
			if(c1 < c2){
				for(int i = this.cases[r2-1][chartoInt(c1)].getColonne()+1; i<chartoInt(this.cases[r1-1][chartoInt(c1)].getColonne())-1;i++){
					if(this.cases[r2-1][i].getContenu() != null){
						return false;
					}
				}
			}
		}
		if(TypeMouvement == "DiagonaleDroiteGauche"){
			if(r1 < r2 && c1 > c2){
				int y = chartoInt(this.cases[r2-1][chartoInt(c2)].getColonne())+1;
				for(int i = this.cases[r2-1][chartoInt(c2)].getRangee()-1;i>this.cases[r1-1][chartoInt(c1)].getRangee();i--){
					if(this.cases[i][y].getContenu()!= null){
						return false;
					}
					y = y + 1;
				}
			}
			if(r1 > r2 && c1 < c2){
				int y = chartoInt(this.cases[r2-1][chartoInt(c2)].getColonne())-1;
				for(int i = this.cases[r2-1][chartoInt(c2)].getRangee()+1;i<this.cases[r1-1][chartoInt(c1)].getRangee()-1;i++){
					if(this.cases[i][y].getContenu()!= null){
						return false;
					}
					y = y - 1;
				}
			}
		}
		if(TypeMouvement == "DiagonaleGaucheDroite"){
			if(r1 > r2 && c1 > c2){
				int y = chartoInt(this.cases[r2-1][chartoInt(c2)].getColonne())+1;
				for(int i = this.cases[r2-1][chartoInt(c2)].getRangee()+1;i<this.cases[r1-1][chartoInt(c1)].getRangee()-1;i++){
					if(this.cases[i][y].getContenu()!= null){
						return false;
					}
					y = y + 1;
				}
			}
			if(r1 < r2 && c1 < c2){
				int y = chartoInt(this.cases[r2-1][chartoInt(c2)].getColonne())-1;
				for(int i = this.cases[r2-1][chartoInt(c2)].getRangee()-1;i>this.cases[r1-1][chartoInt(c1)].getRangee();i--){
					if(this.cases[i][y].getContenu()!= null){
						return false;
					}
					y = y - 1;
				}
			}
		}
		return true;
	}
			
	//Cette méthode permet de tester si une pièce peut être déplacé d'une case à une autre dans la configuration de plateau actuelle.
	public boolean deplacementPiece(char c1,int r1, char c2, int r2){
		//Utilise chartoInt pour transformer les charactères en chiffre(coordonnées)
		int x1 = this.chartoInt(c1);
		int x2 = this.chartoInt(c2);
		Case depart = this.cases[r1-1][x1];
		Case arrive = this.cases[r2-1][x2];
		//Teste si les deux cases sélectionnés sont les mêmes ou si la première case choisi est vide.
		if(depart != arrive && depart.contenu != null){
			//Teste si la case est vide:
			if(arrive.contenu != null){
				//Si elle ne l'est pas, alors il ya une vérification pour voir si les deux cases sont de la même couleur, si elles sont pas alors il y a un test de la méthode deplacement de la pièce puis il y a une vérification qu'aucune pièce n'est sur le chemin sauf si c'est un cavalier.
				if(depart.contenu.memeCouleur(arrive.contenu) != true && depart.getContenu().deplacement(c2,r2) == true && (this.peutTraverser(c1,r1,c2,r2) == true || depart.contenu.nom == "Cavalier")){
					arrive.contenu = depart.contenu;
					depart.contenu = null;
					return true;
				}
			}	
			//so elle l'est alors le déplacement a lieu après vérification de la méthode deplacement de la pièce et celle du chemin
			else if(depart.getContenu().deplacement(c2,r2) == true && (this.peutTraverser(c1,r1,c2,r2) == true || depart.contenu.nom == "Cavalier")){
				arrive.contenu = depart.contenu;
				depart.contenu = null;
				return true;
			}
		}
		return false;
	}
	//Permet d'afficher le plateau en 'scannant' le contenu de chacune des cases et d'afficher leur 'Apparence'
	public void affichage(){
		String s;
		System.out.println(" "+"  A   B   C   D   E   F   G   H");
		for(int i = 0; i<8; i++){
			System.out.println(" "+"----------------------------------");
			s = "" + (-i+8);
			for(int y = 0; y<8;y++){
				if(this.cases[i][y].getContenu() == null){
					s = s + "|   ";
				}
				else{
					s = s + "| " + this.cases[i][y].getContenu().getApparence();
				}
			}
			s = s +" |";
			System.out.println(s);
		}
		System.out.println(" "+"----------------------------------");
	}		
}