
public class Pion extends Piece{
	
	public Pion(char c, int r){
		super(c,r);
		this.nom = "Pion";
		if(this.couleur == "Blanc"){
			this.apparence = "PB";
		}
		else{
			this.apparence = "PN";
		}
	}
	
	public String getApparence(){
		return this.apparence;
	}
	
	public boolean deplacement(char c, int r){
		boolean a = false;
		if(this.couleur == "Noir"){
			if(this.premier_mvt == false){
				if(r != this.rangee && (r == this.rangee + 2 || r == this.rangee + 1) && c == this.colonne){
					this.colonne = c;
					this.rangee = r;
					a = true;
					this.premier_mvt = true;
				}
			}
			else if(r != this.rangee && r == this.rangee + 1 && c == this.colonne){
				this.colonne = c;
				this.rangee = r;
				a = true;
			}
		}
		if(this.couleur == "Blanc"){
			if(this.premier_mvt == false){
				if(r != this.rangee && (r == this.rangee - 2 || r == this.rangee - 1)&& c == this.colonne){
					this.colonne = c;
					this.rangee = r;
					a = true;
					this.premier_mvt = true;
				}
			}
			else if(r != this.rangee && r == this.rangee - 1 && c == this.colonne){
				this.colonne = c;
				this.rangee = r;
				a = true;
			}
		}
		return a;
	}
}