import java.util.*;

public class Case {
	// Une case possède un contenu(Pièce),une rangée et une colonne.
	protected Piece contenu;
	protected char colonne;
	protected int rangee;
	//Constructeur vide
	public Case(){
		this.contenu = new Piece();
		this.colonne = 'A';
		this.rangee = 0;
	}
	//Constructeur avec Pièce,rangée et colonne
	public Case(Piece p,char c, int r){
		this.contenu = p;
		this.colonne = c;
		this.rangee = r;
	}
	//Constructeur sans contenu. Donc Case vide.
	public Case(char c, int r){
		this.contenu = null;
		this.colonne = c;
		this.rangee = r;
	}
	
	public Case(Case c){
		this.contenu = c.getContenu();
		this.colonne = c.getColonne();
		this.rangee = c.getRangee();
	}
	
	//getters/setters
	public Piece getContenu(){
		return this.contenu;
	}
	
	public char getColonne(){
		return this.colonne;
	}
	
	public int getRangee(){
		return this.rangee;
	}
	
	public void setContenu(Piece p){
		this.contenu = p;
	}
	
	public void setColonne(char c){
		this.colonne = c;
	}
	
	public void setRangee(int r){
		this.rangee = r;
	}
	
}	