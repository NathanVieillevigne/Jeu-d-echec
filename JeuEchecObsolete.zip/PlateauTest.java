import java.util.*;

public class PlateauTest {
	
	public static void main(String[] args) {
		String joueur1 = "Blanc";
		String joueur2 = "Noir";
		String deplacementJoueur;
		String depart;
		String arrive;
		Plateau plateaudejeu = new Plateau();
		Scanner input = new Scanner(System.in);
		plateaudejeu.affichage();
		while(plateaudejeu.etmath(plateaudejeu.echec()) == null){
			deplacementJoueur = input.nextLine();
			depart = deplacementJoueur.substring(0,2);
			System.out.println(depart);
			arrive = deplacementJoueur.substring(2,4);
			plateaudejeu.deplacementPiece(depart.charAt(0),Integer.parseInt(depart.substring(1)),arrive.charAt(0),Integer.parseInt(arrive.substring(1)));
			plateaudejeu.affichage();
		}
	}
}
			
			